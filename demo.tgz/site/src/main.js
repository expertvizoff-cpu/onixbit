import { createLightStream } from './light-stream.js';

const hero = document.getElementById('hero');
const panel = document.getElementById('workflow-panel');
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const finePointer = window.matchMedia('(pointer: fine)');
const canvas = document.getElementById('light-stream');
const stream = createLightStream(canvas, hero, { reducedMotion: reducedMotion.matches });
const pauseButton = document.getElementById('flow-toggle');
const runButton = document.getElementById('run-flow');
const flowStatus = document.getElementById('flow-status');
const feed = document.getElementById('run-feed');
const cursor = document.querySelector('.cursor-ring');
let paused = reducedMotion.matches;
let cycleTimer = 0;
let cycleFrame = 0;
let running = false;
let stopped = false;
let tiltX = 0, tiltY = 0, targetX = 0, targetY = 0;
let cursorX = -100, cursorY = -100, mouseX = -100, mouseY = -100;
let lastTiltFrame = 0;
let flowTimers = [];
let manualRun = false;

function later(callback, ms) {
  const id = window.setTimeout(callback, ms);
  flowTimers.push(id);
  return id;
}
function clearFlowTimers() {
  flowTimers.forEach(clearTimeout);
  flowTimers = [];
  clearTimeout(cycleTimer);
}
function resetFlow() {
  document.querySelectorAll('.flow-node, .flow-path').forEach((node) => node.classList.remove('is-active', 'is-complete'));
}
function activateNode(id, path) {
  document.getElementById(id)?.classList.add('is-active');
  if (path) document.querySelectorAll(`[data-branch="${path}"]`).forEach((line) => line.classList.add('is-active'));
}
function completeNode(id) {
  const node = document.getElementById(id);
  node?.classList.remove('is-active');
  node?.classList.add('is-complete');
}
function finishFlow() {
  running = false;
  runButton.disabled = false;
  runButton.classList.remove('is-running');
  runButton.setAttribute('aria-busy', 'false');
  if (flowStatus) flowStatus.textContent = 'выполнено';
  const result = document.getElementById('flow-announcement');
  if (result && manualRun) result.textContent = 'Пример завершён: заявка зарегистрирована в CRM, заказ передан в 1С.';
  if (feed) {
    const rows = [...feed.children];
    rows.forEach((row) => row.classList.remove('is-new'));
    rows.at(-1)?.classList.add('is-new');
  }
  if (!paused && !document.hidden) cycleTimer = window.setTimeout(() => runFlow(false), 6000);
}
function runFlow(manual = true) {
  if (running || (!manual && (paused || document.hidden))) return;
  clearFlowTimers();
  resetFlow();
  running = true;
  manualRun = manual;
  if (manual) document.getElementById('flow-announcement').textContent = '';
  runButton.disabled = true;
  runButton.setAttribute('aria-busy', 'true');
  runButton.classList.add('is-running');
  if (flowStatus) flowStatus.textContent = 'обработка';
  activateNode('trigger-node');
  const delay = reducedMotion.matches ? 0 : 800;
  later(() => { completeNode('trigger-node'); activateNode('crm-node', 'true'); }, delay);
  later(() => { completeNode('crm-node'); activateNode('order-node', 'true'); }, delay * 2.2);
  later(() => { completeNode('order-node'); finishFlow(); }, delay * 3.5 + 50);
}

function updatePause() {
  document.body.dataset.motion = paused ? 'paused' : 'playing';
  stream.setPaused(paused);
  pauseButton?.setAttribute('aria-pressed', String(paused));
  if (pauseButton) pauseButton.setAttribute('aria-label', paused ? 'Включить анимацию' : 'Остановить анимацию');
  const text = pauseButton?.querySelector('span');
  if (text) text.textContent = paused ? 'Включить движение' : 'Остановить движение';
  if (paused) {
    cancelAnimationFrame(cycleFrame);
    cycleFrame = 0;
    clearFlowTimers();
    running = false;
    runButton.disabled = false;
    runButton.setAttribute('aria-busy', 'false');
    runButton.classList.remove('is-running');
    if (flowStatus) flowStatus.textContent = 'готово';
    resetFlow();
    targetX = targetY = 0;
    tiltX = tiltY = 0;
    panel.style.setProperty('--tilt-x', '0deg');
    panel.style.setProperty('--tilt-y', '0deg');
  } else cycleTimer = window.setTimeout(() => runFlow(false), 1800);
}

function animateTilt(now) {
  cycleFrame = 0;
  if (stopped || paused || document.hidden) return;
  if (now - lastTiltFrame < 1000 / 45) { cycleFrame = requestAnimationFrame(animateTilt); return; }
  lastTiltFrame = now;
  tiltX += (targetX - tiltX) * 0.07;
  tiltY += (targetY - tiltY) * 0.07;
  panel.style.setProperty('--tilt-x', `${tiltX.toFixed(3)}deg`);
  panel.style.setProperty('--tilt-y', `${tiltY.toFixed(3)}deg`);
  if (cursor && finePointer.matches) {
    cursorX += (mouseX - cursorX) * 0.11;
    cursorY += (mouseY - cursorY) * 0.11;
    cursor.style.transform = `translate3d(${cursorX}px, ${cursorY}px, 0)`;
  }
  if (Math.abs(targetX - tiltX) + Math.abs(targetY - tiltY) > 0.002 || Math.abs(mouseX - cursorX) + Math.abs(mouseY - cursorY) > 0.05) cycleFrame = requestAnimationFrame(animateTilt);
}

hero.addEventListener('pointermove', (event) => {
  if (!finePointer.matches || paused) return;
  const rect = hero.getBoundingClientRect();
  const x = (event.clientX - rect.left) / rect.width - 0.5;
  const y = (event.clientY - rect.top) / rect.height - 0.5;
  targetX = -y * 3.5;
  targetY = x * 4;
  mouseX = event.clientX;
  mouseY = event.clientY;
  cursor?.classList.add('is-visible');
  stream.setPointer(x, y);
  if (!cycleFrame) cycleFrame = requestAnimationFrame(animateTilt);
});
hero.addEventListener('pointerleave', () => {
  targetX = targetY = 0;
  cursor?.classList.remove('is-visible');
  stream.setPointer(0, 0);
  if (!cycleFrame && !paused) cycleFrame = requestAnimationFrame(animateTilt);
});
runButton.addEventListener('click', () => runFlow(true));
pauseButton?.addEventListener('click', () => { paused = !paused; updatePause(); });
reducedMotion.addEventListener('change', (event) => { paused = event.matches; updatePause(); });

const menuButton = document.getElementById('menu-toggle');
const menu = document.getElementById('mobile-menu');
function closeMenu() {
  if (!menuButton || !menu) return;
  menuButton.setAttribute('aria-expanded', 'false');
  menu.hidden = true;
}
menuButton?.addEventListener('click', () => {
  const expanded = menuButton.getAttribute('aria-expanded') === 'true';
  menuButton.setAttribute('aria-expanded', String(!expanded));
  menu.hidden = expanded;
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && menu && !menu.hidden) { closeMenu(); menuButton.focus(); }
});
document.addEventListener('click', (event) => {
  if (menu && !menu.hidden && !menu.contains(event.target) && !menuButton.contains(event.target)) closeMenu();
});
window.addEventListener('resize', () => { if (innerWidth > 900) closeMenu(); });
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    clearFlowTimers();
    running = false;
    runButton.disabled = false;
    runButton.setAttribute('aria-busy', 'false');
    runButton.classList.remove('is-running');
    cancelAnimationFrame(cycleFrame);
  } else {
    cycleFrame = requestAnimationFrame(animateTilt);
    if (!paused) cycleTimer = window.setTimeout(() => runFlow(false), 1500);
  }
});
window.addEventListener('pagehide', (event) => {
  if (event.persisted) return;
  stopped = true; clearFlowTimers(); cancelAnimationFrame(cycleFrame); stream.dispose();
});
updatePause();
cycleFrame = requestAnimationFrame(animateTilt);

// Deterministic visual-review hook: opt-in only, has no effect on the normal page.
if (new URLSearchParams(location.search).get('capture') === '1') {
  paused = true;
  updatePause();
  stream.renderAt(5);
  document.body.dataset.capture = 'true';
}
