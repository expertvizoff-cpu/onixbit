import * as THREE from '../assets/three/three.module.min.js';

// Original reconstruction from the recording. No Relay source is used.
// Document-space geometry is viewed through a viewport-size, scrolling camera.
const HERO_WAYPOINTS = [
  [1.20, -0.12], [0.94, 0.08], [0.77, 0.22], [0.55, 0.43],
  [0.385, 0.615], [0.355, 0.687], [0.43, 0.765], [0.66, 0.97], [0.72, 1.28],
];
const SECTION_BENDS = {
  integrations: [],
  process: [[0.20, 0.83], [0.62, 0.32], [0.98, 0.56]],
  statement: [[0.20, 0.62], [0.95, 0.98]],
  reliability: [[0.60, 0.88]],
  dashboard: [[0.32, 0.49], [0.96, 0.18]],
  metrics: [[0.30, 0.17], [0.96, 0.58]],
  scenarios: [],
  estimate: [[0.35, 0.85], [0.96, 0.33]],
  contact: [[0.28, 0.20], [0.96, 0.79]],
  footer: [[0.70, 0.68]],
};
const vertexShader = `
  attribute vec2 aNormal;
  attribute float aProgress;
  attribute float aPhase;
  attribute float aOffset;
  attribute float aEnvelope;
  attribute float aLower;
  uniform float uTime;
  uniform float uHeight;
  varying vec2 vUv;
  varying float vProgress;
  varying float vPhase;
  varying float vLower;
  varying float vEnvelope;
  void main() {
    vUv = uv;
    vProgress = aProgress;
    vPhase = aPhase;
    vEnvelope = aEnvelope;
    vLower = aLower;
    float pin = 0.24 + 0.76 * (1.0 - exp(-pow((aProgress - 0.687) * 8.0, 2.0)));
    float wave = sin(aProgress * 19.0 + aPhase * 6.7 + uTime * 0.38) * 0.013
      + sin(aProgress * 32.0 - uTime * 0.27 + aPhase * 3.1) * 0.004;
    wave += sin(aProgress * 13.0 + uTime * 0.12) * 0.030 * exp(-pow((aProgress - 0.22) * 3.5, 2.0));
    vec3 p = position;
    p.xy += aNormal * (aOffset * mix(1.0, 1.65, vLower) + wave * uHeight) * pin * aEnvelope;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
  }
`;
const fragmentShader = `
  uniform float uTime;
  uniform vec3 uColor;
  uniform float uOpacity;
  uniform float uSoftness;
  uniform float uLowerOpacity;
  varying vec2 vUv;
  varying float vProgress;
  varying float vPhase;
  varying float vLower;
  varying float vEnvelope;
  void main() {
    float edge = abs(vUv.y * 2.0 - 1.0);
    float line = exp(-edge * edge * uSoftness);
    line *= 1.0 - smoothstep(0.70, 1.0, edge);
    float flow = 0.62 + 0.38 * sin(vProgress * 26.0 - uTime * 0.8 + vPhase * 9.0);
    float pulse = pow(max(0.0, sin(vProgress * 9.0 - uTime * 0.45 + vPhase)), 12.0);
    float intensity = (flow + pulse * 0.26) * uOpacity * mix(1.0, uLowerOpacity, vLower);
    intensity *= mix(1.0, sqrt(vEnvelope), vLower);
    gl_FragColor = vec4(uColor, line * intensity);
  }
`;
const pointVertex = `
  attribute float aSize;
  attribute float aPhase;
  attribute float aStrength;
  uniform float uTime;
  uniform float uDpr;
  varying float vPhase;
  varying float vStrength;
  void main() {
    vPhase = aPhase;
    vStrength = aStrength;
    vec3 p = position;
    p.x += sin(uTime * 0.07 + aPhase) * 5.0;
    p.y += cos(uTime * 0.05 + aPhase * 2.0) * 7.0;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
    gl_PointSize = aSize * uDpr;
  }
`;
const pointFragment = `
  uniform float uTime;
  varying float vPhase;
  varying float vStrength;
  void main() {
    float d = length(gl_PointCoord - 0.5) * 2.0;
    float alpha = exp(-d * d * 4.0) * (1.0 - smoothstep(0.65, 1.0, d));
    alpha *= (0.035 + 0.045 * sin(vPhase + uTime * 0.18)) * vStrength;
    gl_FragColor = vec4(0.70, 0.78, 0.44, alpha);
  }
`;
const glowFragment = `
  varying float vStrength;
  void main() {
    float d = length(gl_PointCoord - 0.5) * 2.0;
    float alpha = exp(-d * d * 4.0) * (1.0 - smoothstep(0.7, 1.0, d));
    gl_FragColor = vec4(0.68, 0.82, 0.30, alpha * 0.030 * vStrength);
  }
`;
function seeded(seed = 1729) {
  return () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

export function createLightStream(canvas, hero, { reducedMotion = false } = {}) {
  const shell = document.getElementById('site-shell') || hero;
  const setGraphics = (state) => { hero.dataset.graphics = state; shell.dataset.graphics = state; };
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: false, powerPreference: 'low-power' });
  } catch {
    setGraphics('fallback');
    return { setPaused() {}, setPointer() {}, dispose() {}, renderAt() {} };
  }
  renderer.setClearColor(0x000000, 0);
  renderer.outputColorSpace = THREE.LinearSRGBColorSpace;
  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(0, 1, 0, 1, -10, 10);
  camera.position.z = 2;
  const materials = [];
  let width = 0, viewportHeight = 0, heroHeight = 0, documentHeight = 0;
  let layoutSignature = '';
  let raf = 0, redrawRaf = 0, resizeRaf = 0;
  let paused = reducedMotion;
  let elapsed = 5, lastFrame = 0, lastDraw = 0;
  let disposed = false, contextLost = false;

  function clearScene() {
    for (const object of [...scene.children]) { object.geometry.dispose(); scene.remove(object); }
    for (const material of materials) material.dispose();
    materials.length = 0;
  }
  function ribbonMaterial({ color, opacity, softness, lowerOpacity }) {
    const material = new THREE.ShaderMaterial({
      vertexShader, fragmentShader, transparent: true, blending: THREE.AdditiveBlending,
      depthWrite: false, depthTest: false, side: THREE.DoubleSide,
      uniforms: {
        uTime: { value: elapsed }, uHeight: { value: heroHeight },
        uColor: { value: new THREE.Color(color) }, uOpacity: { value: opacity }, uSoftness: { value: softness },
        uLowerOpacity: { value: lowerOpacity },
      },
    });
    materials.push(material);
    return material;
  }
  function pointMaterial(fragment) {
    const material = new THREE.ShaderMaterial({
      vertexShader: pointVertex, fragmentShader: fragment, transparent: true,
      blending: THREE.AdditiveBlending, depthWrite: false, depthTest: false,
      uniforms: { uTime: { value: elapsed }, uDpr: { value: renderer.getPixelRatio() } },
    });
    materials.push(material);
    return material;
  }
  // Merge filaments into viewport-sized chunks, with shared materials. Offscreen
  // chunks are culled instead of drawing every triangle along the full document.
  function addRibbonChunk(samples, ribbons, material, broad) {
    const positions = [], normals = [], progress = [], phases = [], offsets = [], envelopes = [], lowerFactors = [], uv = [], indices = [];
    for (const ribbon of ribbons) {
      const start = positions.length / 3;
      for (let i = 0; i < samples.length; i++) {
        const { p, n, logicalProgress, envelope, lower } = samples[i];
        const halfWidth = heroHeight * (broad ? 0.020 * (1 + lower * 2.6) * ribbon.sheetWidth : ribbon.coreWidth) * envelope;
        for (const side of [-1, 1]) {
          positions.push(p.x + n.x * halfWidth * side, p.y + n.y * halfWidth * side, 0);
          normals.push(n.x, n.y); progress.push(logicalProgress);
          phases.push(ribbon.phase); offsets.push(ribbon.offset); envelopes.push(envelope); lowerFactors.push(lower); uv.push(logicalProgress, (side + 1) / 2);
        }
        if (i < samples.length - 1) {
          const a = start + i * 2;
          indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
        }
      }
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('aNormal', new THREE.Float32BufferAttribute(normals, 2));
    geometry.setAttribute('aProgress', new THREE.Float32BufferAttribute(progress, 1));
    geometry.setAttribute('aPhase', new THREE.Float32BufferAttribute(phases, 1));
    geometry.setAttribute('aOffset', new THREE.Float32BufferAttribute(offsets, 1));
    geometry.setAttribute('aEnvelope', new THREE.Float32BufferAttribute(envelopes, 1));
    geometry.setAttribute('aLower', new THREE.Float32BufferAttribute(lowerFactors, 1));
    geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geometry.setIndex(indices); geometry.computeBoundingSphere();
    geometry.boundingSphere.radius += heroHeight * 0.23; // Shader offset + wave.
    scene.add(new THREE.Mesh(geometry, material));
  }
  function addPoints(positions, sizes, phases, strengths, material) {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('aSize', new THREE.Float32BufferAttribute(sizes, 1));
    geometry.setAttribute('aPhase', new THREE.Float32BufferAttribute(phases, 1));
    geometry.setAttribute('aStrength', new THREE.Float32BufferAttribute(strengths, 1));
    geometry.computeBoundingSphere();
    geometry.boundingSphere.radius += Math.max(...sizes, 0) / 2 + 10;
    scene.add(new THREE.Points(geometry, material));
  }
  function buildScene(heroTop, sections) {
    clearScene();
    const mobile = width < 760;
    const xScale = mobile ? 1.48 : 1, xOffset = mobile ? -width * 0.36 : 0;
    const points = HERO_WAYPOINTS.map(([x, y]) =>
      new THREE.Vector3(x * width * xScale + xOffset, heroTop + y * heroHeight, 0));
    const minGap = Math.max(100, heroHeight * 0.22);
    for (const [index, section] of sections.entries()) {
      const bends = SECTION_BENDS[section.name] || [[0.46, index % 2 ? 0.16 : 0.86]];
      for (const [fraction, x] of bends) {
        const y = section.top + section.height * fraction;
        if (y > points.at(-1).y + minGap) points.push(new THREE.Vector3(x * width, y, 0));
      }
    }
    // Covers an unmarked footer and remains safe before sections are inserted.
    while (points.at(-1).y < documentHeight - heroHeight * 0.45) {
      const last = points.at(-1);
      points.push(new THREE.Vector3((last.x > width * 0.5 ? 0.15 : 0.87) * width,
        Math.min(last.y + heroHeight * 1.1, documentHeight), 0));
    }
    const last = points.at(-1);
    points.push(new THREE.Vector3(last.x + (last.x > width * 0.5 ? 0.18 : -0.18) * width,
      Math.max(last.y + heroHeight * 0.42, documentHeight + heroHeight * 0.22), 0));
    const curve = new THREE.CatmullRomCurve3(points, false, 'centripetal', 0.5);
    const steps = Math.min(2400, Math.max(260, Math.ceil(curve.getLength() / (mobile ? 11 : 8))));
    const samples = [];
    for (let i = 0; i <= steps; i++) {
      const t = i / steps, p = curve.getPoint(t), tangent = curve.getTangent(t);
      samples.push({ p, n: new THREE.Vector2(-tangent.y, tangent.x).normalize(), envelope: 1,
        // Preserve the hero's original 0..1 shader domain on the extended curve.
        logicalProgress: (p.y - heroTop) / heroHeight,
        lower: THREE.MathUtils.smoothstep(p.y - heroTop, heroHeight, heroHeight * 1.35) });
    }
    // An offset curve folds when its spread exceeds the local radius. Estimate
    // curvature from nearby tangents, then taper every displacement together.
    // The original hero is excluded; its deliberate pinch remains unchanged.
    const caps = samples.map((sample, index) => {
      const before = samples[Math.max(0, index - 2)], after = samples[Math.min(steps, index + 2)];
      const angle = Math.abs(Math.atan2(before.n.x * after.n.y - before.n.y * after.n.x, before.n.dot(after.n)));
      const distance = before.p.distanceTo(sample.p) + sample.p.distanceTo(after.p);
      const radius = angle > 0.0001 ? distance / angle : Infinity;
      return Math.min(1, radius * 0.30 / (heroHeight * 0.20));
    });
    // Propagate each tight-turn limit outwards so the bundle contracts gradually
    // instead of replacing a folded fan with an abrupt needle-shaped pinch.
    const feather = heroHeight * 0.42;
    for (let i = 1; i <= steps; i++) caps[i] = Math.min(caps[i], caps[i - 1] + samples[i].p.distanceTo(samples[i - 1].p) / feather);
    for (let i = steps - 1; i >= 0; i--) caps[i] = Math.min(caps[i], caps[i + 1] + samples[i].p.distanceTo(samples[i + 1].p) / feather);
    for (let i = 0; i <= steps; i++) {
      const lower = samples[i].lower;
      samples[i].envelope = 1 - lower * (1 - caps[i]);
    }
    const rand = seeded(), groups = { lime: [], blue: [] }, count = mobile ? 24 : 38;
    for (let i = 0; i < count; i++) {
      groups[i % 3 === 2 ? 'blue' : 'lime'].push({ phase: rand() * Math.PI * 2,
        offset: (i / (count - 1) - 0.5) * heroHeight * 0.15, coreWidth: 0.001 + rand() * 0.0013,
        sheetWidth: 0.7 + rand() * 0.7 });
    }
    const layers = [
      { ribbons: groups.lime.filter((_, i) => i % 3 === 0), broad: true, material: ribbonMaterial({ color: '#dce9a1', opacity: 0.28, softness: 3.2, lowerOpacity: 0.56 }) },
      { ribbons: groups.blue.filter((_, i) => i % 2 === 0), broad: true, material: ribbonMaterial({ color: '#83bdde', opacity: 0.26, softness: 3.2, lowerOpacity: 0.70 }) },
      { ribbons: groups.lime, broad: false, material: ribbonMaterial({ color: '#e3eeaf', opacity: 0.24, softness: 3, lowerOpacity: 0.025 }) },
      { ribbons: groups.blue, broad: false, material: ribbonMaterial({ color: '#95c6df', opacity: 0.18, softness: 3, lowerOpacity: 0.025 }) },
    ];
    const glowMaterial = pointMaterial(glowFragment), dustMaterial = pointMaterial(pointFragment);
    const glowStep = Math.max(1, Math.round(steps / ((points.length - 1) / 8 * 100)));
    const chunkSteps = Math.max(24, Math.ceil(steps / Math.max(1, Math.ceil(documentHeight / Math.max(600, viewportHeight)))));
    for (let start = 0; start < steps; start += chunkSteps) {
      const end = Math.min(steps, start + chunkSteps), chunk = samples.slice(start, end + 1);
      const glowPositions = [], glowSizes = [], glowPhases = [], glowStrengths = [];
      for (let i = start; i < end; i++) {
        if (i % glowStep !== 0) continue;
        const { p, lower } = samples[i];
        glowPositions.push(p.x, p.y, 0);
        glowSizes.push(Math.min(heroHeight * 0.26, 230) * (1 + lower * 0.36));
        glowPhases.push(i * 0.31); glowStrengths.push(1 - lower * 0.60);
      }
      if (glowSizes.length) addPoints(glowPositions, glowSizes, glowPhases, glowStrengths, glowMaterial);
      for (const layer of layers) addRibbonChunk(chunk, layer.ribbons, layer.material, layer.broad);
      const top = Math.max(0, chunk[0].p.y), bottom = Math.min(documentHeight, chunk.at(-1).p.y);
      if (bottom <= top) continue;
      const positions = [], sizes = [], phases = [], strengths = [];
      const dustCount = Math.ceil((bottom - top) / heroHeight * (mobile ? 65 : 110));
      for (let i = 0; i < dustCount; i++) {
        const y = top + rand() * (bottom - top);
        positions.push(rand() * width, y, 0); sizes.push(i % 8 === 0 ? 6 + rand() * 14 : 1.5 + rand() * 2);
        phases.push(rand() * Math.PI * 2); strengths.push(y < heroTop + heroHeight ? 1 : 0.65);
      }
      addPoints(positions, sizes, phases, strengths, dustMaterial);
    }
  }
  function draw(time) {
    if (disposed || contextLost || !width || !viewportHeight) return;
    const scroll = Math.max(0, window.scrollY || 0);
    camera.top = scroll; camera.bottom = scroll + viewportHeight; camera.updateProjectionMatrix();
    for (const material of materials) material.uniforms.uTime.value = time;
    renderer.render(scene, camera); setGraphics('webgl');
  }
  function resize(force = false) {
    resizeRaf = 0;
    if (disposed || contextLost) return;
    const scroll = window.scrollY || 0, heroRect = hero.getBoundingClientRect(), shellRect = shell.getBoundingClientRect();
    const sections = [...shell.querySelectorAll('[data-scene]')].map((element) => {
      const rect = element.getBoundingClientRect();
      return { name: element.dataset.scene, top: rect.top + scroll, height: rect.height };
    }).filter((section) => section.height > 0).sort((a, b) => a.top - b.top);
    const nextWidth = Math.max(1, document.documentElement.clientWidth || window.innerWidth);
    const nextViewportHeight = Math.max(1, window.innerHeight), nextHeroHeight = Math.max(1, Math.round(heroRect.height));
    const nextDocumentHeight = Math.max(nextHeroHeight, Math.ceil(shellRect.top + scroll + shellRect.height));
    const signature = [nextWidth, nextViewportHeight, nextHeroHeight, nextDocumentHeight, Math.round(heroRect.top + scroll),
      window.devicePixelRatio, ...sections.map((s) => `${s.name}:${Math.round(s.top)}:${Math.round(s.height)}`)].join('|');
    if (!force && signature === layoutSignature) return;
    layoutSignature = signature;
    width = nextWidth; viewportHeight = nextViewportHeight; heroHeight = nextHeroHeight; documentHeight = nextDocumentHeight;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, width < 760 ? 1.25 : 1.5));
    renderer.setSize(width, viewportHeight, false); camera.right = width;
    buildScene(heroRect.top + scroll, sections); draw(elapsed);
  }
  function scheduleResize() {
    if (!resizeRaf && !disposed && !contextLost) resizeRaf = requestAnimationFrame(() => resize());
  }
  function tick(now) {
    raf = 0;
    if (disposed || contextLost || paused || document.hidden) return;
    raf = requestAnimationFrame(tick);
    if (now - lastDraw < 1000 / (width < 760 ? 30 : 45)) return;
    elapsed += lastFrame ? Math.min((now - lastFrame) / 1000, 0.1) : 0; lastFrame = lastDraw = now; draw(elapsed);
  }
  function resume() {
    lastFrame = 0;
    if (!raf && !paused && !document.hidden && !disposed && !contextLost) raf = requestAnimationFrame(tick);
  }
  function onScroll() {
    // Paused, capture, and reduced-motion scenes still follow document scrolling.
    if (raf || redrawRaf || document.hidden || disposed || contextLost) return;
    redrawRaf = requestAnimationFrame(() => { redrawRaf = 0; draw(elapsed); });
  }
  function onVisibility() {
    if (document.hidden) {
      cancelAnimationFrame(raf); cancelAnimationFrame(redrawRaf); raf = redrawRaf = 0;
    } else { onScroll(); resume(); }
  }
  function onContextLost(event) {
    event.preventDefault(); contextLost = true;
    cancelAnimationFrame(raf); cancelAnimationFrame(redrawRaf); cancelAnimationFrame(resizeRaf);
    raf = redrawRaf = resizeRaf = 0;
    // Release geometry listeners and VAO/program caches against the lost
    // context. After Three restores its GL state, those old objects no longer
    // belong to it and must not be disposed through the fresh context.
    clearScene();
    renderer.renderLists.dispose();
    layoutSignature = '';
    setGraphics('fallback');
  }
  function onContextRestored() { contextLost = false; resize(true); resume(); }
  const resizeObserver = new ResizeObserver(scheduleResize);
  resizeObserver.observe(shell);
  if (shell !== hero) resizeObserver.observe(hero);
  for (const section of shell.querySelectorAll('[data-scene]')) resizeObserver.observe(section);
  window.addEventListener('resize', scheduleResize);
  window.addEventListener('scroll', onScroll, { passive: true });
  document.addEventListener('visibilitychange', onVisibility);
  canvas.addEventListener('webglcontextlost', onContextLost);
  canvas.addEventListener('webglcontextrestored', onContextRestored);
  document.fonts?.ready.then(scheduleResize);
  resize(); resume();
  return {
    setPaused(value) {
      paused = Boolean(value);
      if (paused) { cancelAnimationFrame(raf); raf = 0; } else resume();
    },
    // Retain the caller API. The bend belongs to the layout, not the pointer.
    setPointer() {},
    renderAt(time) { this.setPaused(true); elapsed = Number.isFinite(time) ? Math.max(0, time) : 5; draw(elapsed); },
    dispose() {
      disposed = true; cancelAnimationFrame(raf); cancelAnimationFrame(redrawRaf); cancelAnimationFrame(resizeRaf);
      resizeObserver.disconnect(); window.removeEventListener('resize', scheduleResize); window.removeEventListener('scroll', onScroll);
      document.removeEventListener('visibilitychange', onVisibility);
      canvas.removeEventListener('webglcontextlost', onContextLost); canvas.removeEventListener('webglcontextrestored', onContextRestored);
      clearScene(); renderer.dispose();
    },
  };
}
