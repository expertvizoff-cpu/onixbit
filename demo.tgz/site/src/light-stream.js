import * as THREE from '../assets/three/three.module.min.js';

// Original reconstruction from the supplied recording. No Relay source is used.
// Pixel-space path keeps the bend attached to the layout, not to the pointer.
const WAYPOINTS = [
  [1.20, -0.12], [0.94, 0.08], [0.77, 0.22], [0.55, 0.43],
  [0.385, 0.615], [0.355, 0.687], [0.43, 0.765], [0.66, 0.97], [0.72, 1.28],
];

const vertexShader = `
  attribute vec2 aNormal;
  attribute float aProgress;
  attribute float aPhase;
  attribute float aOffset;
  uniform float uTime;
  uniform float uHeight;
  uniform vec2 uPointer;
  varying vec2 vUv;
  varying float vProgress;
  varying float vPhase;
  void main() {
    vUv = uv;
    vProgress = aProgress;
    vPhase = aPhase;
    float pin = 0.12 + 0.88 * (1.0 - exp(-pow((aProgress - 0.625) * 8.0, 2.0)));
    float wave = sin(aProgress * 19.0 + aPhase * 6.7 + uTime * 0.25) * 0.013
      + sin(aProgress * 32.0 - uTime * 0.18 + aPhase * 3.1) * 0.004;
    wave += sin(aProgress * 13.0 + uTime * 0.12) * 0.026 * exp(-pow((aProgress - 0.22) * 3.5, 2.0));
    vec3 p = position;
    p.xy += aNormal * (aOffset + wave * uHeight) * pin;
    p.xy += uPointer * pin * 2.0;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
  }
`;

const fragmentShader = `
  uniform float uTime;
  uniform vec3 uColor;
  uniform float uOpacity;
  uniform float uSoftness;
  varying vec2 vUv;
  varying float vProgress;
  varying float vPhase;
  void main() {
    float edge = abs(vUv.y * 2.0 - 1.0);
    float line = exp(-edge * edge * uSoftness);
    line *= 1.0 - smoothstep(0.70, 1.0, edge);
    float flow = 0.62 + 0.38 * sin(vProgress * 26.0 - uTime * 0.8 + vPhase * 9.0);
    float pulse = pow(max(0.0, sin(vProgress * 9.0 - uTime * 0.45 + vPhase)), 12.0);
    float intensity = (flow + pulse * 0.26) * uOpacity;
    gl_FragColor = vec4(uColor, line * intensity);
  }
`;

const pointVertex = `
  attribute float aSize;
  attribute float aPhase;
  uniform float uTime;
  uniform float uDpr;
  varying float vPhase;
  void main() {
    vPhase = aPhase;
    vec3 p = position;
    p.x += sin(uTime * 0.07 + aPhase) * 5.0;
    p.y += cos(uTime * 0.05 + aPhase * 2.0) * 7.0;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
    gl_PointSize = aSize * uDpr;
  }
`;
const pointFragment = `
  uniform float uTime;
  varying float vPhase;
  void main() {
    float d = length(gl_PointCoord - 0.5) * 2.0;
    float alpha = exp(-d * d * 4.0) * (1.0 - smoothstep(0.65, 1.0, d));
    alpha *= (0.035 + 0.045 * sin(vPhase + uTime * 0.18));
    gl_FragColor = vec4(0.70, 0.78, 0.44, alpha);
  }
`;

function seeded(seed = 1729) {
  return () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

export function createLightStream(canvas, hero, { reducedMotion = false } = {}) {
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: false, powerPreference: 'low-power' });
  } catch {
    hero.dataset.graphics = 'fallback';
    return { setPaused() {}, setPointer() {}, dispose() {}, renderAt() {} };
  }

  renderer.setClearColor(0x000000, 0);
  renderer.outputColorSpace = THREE.LinearSRGBColorSpace;
  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(0, 1, 0, 1, -10, 10);
  camera.position.z = 2;
  const pointer = new THREE.Vector2();
  const pointerTarget = new THREE.Vector2();
  const materials = [];
  let width = 0;
  let height = 0;
  let raf = 0;
  let paused = reducedMotion;
  let visible = true;
  let elapsed = 5;
  let lastFrame = 0;
  let lastDraw = 0;
  let disposed = false;
  let contextLost = false;

  function addRibbon(curve, { offset = 0, halfWidth, opacity, color, phase, softness = 5 }) {
    const steps = 220;
    const positions = [], normals = [], progress = [], phases = [], offsets = [], uv = [], indices = [];
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const p = curve.getPoint(t);
      const tangent = curve.getTangent(t);
      const n = new THREE.Vector2(-tangent.y, tangent.x).normalize();
      for (const side of [-1, 1]) {
        positions.push(p.x + n.x * halfWidth * side, p.y + n.y * halfWidth * side, 0);
        normals.push(n.x, n.y);
        progress.push(t);
        phases.push(phase);
        offsets.push(offset);
        uv.push(t, (side + 1) / 2);
      }
      if (i < steps) {
        const a = i * 2;
        indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
      }
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('aNormal', new THREE.Float32BufferAttribute(normals, 2));
    geometry.setAttribute('aProgress', new THREE.Float32BufferAttribute(progress, 1));
    geometry.setAttribute('aPhase', new THREE.Float32BufferAttribute(phases, 1));
    geometry.setAttribute('aOffset', new THREE.Float32BufferAttribute(offsets, 1));
    geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geometry.setIndex(indices);
    const material = new THREE.ShaderMaterial({
      vertexShader, fragmentShader,
      transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, depthTest: false,
      side: THREE.DoubleSide,
      uniforms: {
        uTime: { value: elapsed }, uHeight: { value: height }, uPointer: { value: pointer },
        uColor: { value: new THREE.Color(color) }, uOpacity: { value: opacity }, uSoftness: { value: softness },
      },
    });
    materials.push(material);
    const mesh = new THREE.Mesh(geometry, material);
    mesh.frustumCulled = false;
    scene.add(mesh);
  }

  function buildScene() {
    for (const object of [...scene.children]) {
      object.geometry.dispose();
      object.material.dispose();
      scene.remove(object);
    }
    materials.length = 0;
    const mobile = width < 760;
    const xScale = mobile ? 1.48 : 1;
    const xOffset = mobile ? -width * 0.36 : 0;
    const curve = new THREE.CatmullRomCurve3(WAYPOINTS.map(([x, y]) =>
      new THREE.Vector3(x * width * xScale + xOffset, y * height, 0)
    ), false, 'centripetal', 0.5);

    // Round Gaussian sprites avoid folded ribbon triangles at the tight turn.
    const glowPositions = [], glowSizes = [], glowPhases = [];
    for (let i = 0; i < 100; i++) {
      const p = curve.getPoint(i / 99);
      glowPositions.push(p.x, p.y, 0);
      glowSizes.push(Math.min(height * 0.26, 230));
      glowPhases.push(i * 0.31);
    }
    const glowGeometry = new THREE.BufferGeometry();
    glowGeometry.setAttribute('position', new THREE.Float32BufferAttribute(glowPositions, 3));
    glowGeometry.setAttribute('aSize', new THREE.Float32BufferAttribute(glowSizes, 1));
    glowGeometry.setAttribute('aPhase', new THREE.Float32BufferAttribute(glowPhases, 1));
    const glowMaterial = new THREE.ShaderMaterial({
      vertexShader: pointVertex,
      fragmentShader: `
        void main() {
          float d = length(gl_PointCoord - 0.5) * 2.0;
          float alpha = exp(-d * d * 4.0) * (1.0 - smoothstep(0.7, 1.0, d));
          gl_FragColor = vec4(0.68, 0.82, 0.30, alpha * 0.030);
        }
      `,
      transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
      uniforms: { uTime: { value: elapsed }, uDpr: { value: renderer.getPixelRatio() } },
    });
    materials.push(glowMaterial);
    scene.add(new THREE.Points(glowGeometry, glowMaterial));
    const count = mobile ? 24 : 38;
    const rand = seeded();
    for (let i = 0; i < count; i++) {
      const phase = rand() * Math.PI * 2;
      const offset = ((i / (count - 1)) - 0.5) * height * 0.15;
      const blue = i % 9 === 2;
      const color = blue ? '#84c4e2' : (i % 4 ? '#d9ef9d' : '#eaffb4');
      addRibbon(curve, { offset, halfWidth: height * 0.016, opacity: blue ? 0.10 : 0.14, color, phase });
      addRibbon(curve, { offset, halfWidth: height * (0.001 + rand() * 0.0013), opacity: blue ? 0.26 : 0.35, color, phase, softness: 3 });
    }

    const positions = [], sizes = [], phases = [];
    for (let i = 0; i < (mobile ? 65 : 125); i++) {
      positions.push(rand() * width, rand() * height, 0);
      sizes.push(i % 8 === 0 ? 6 + rand() * 14 : 1.5 + rand() * 2);
      phases.push(rand() * Math.PI * 2);
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('aSize', new THREE.Float32BufferAttribute(sizes, 1));
    geometry.setAttribute('aPhase', new THREE.Float32BufferAttribute(phases, 1));
    const material = new THREE.ShaderMaterial({
      vertexShader: pointVertex, fragmentShader: pointFragment, transparent: true,
      blending: THREE.AdditiveBlending, depthWrite: false,
      uniforms: { uTime: { value: elapsed }, uDpr: { value: renderer.getPixelRatio() } },
    });
    materials.push(material);
    scene.add(new THREE.Points(geometry, material));
  }

  function draw(time) {
    for (const material of materials) material.uniforms.uTime.value = time;
    renderer.render(scene, camera);
    hero.dataset.graphics = 'webgl';
  }

  function resize() {
    if (disposed) return;
    const rect = hero.getBoundingClientRect();
    const nextWidth = Math.round(rect.width), nextHeight = Math.round(rect.height);
    if (nextWidth === width && nextHeight === height) return;
    width = nextWidth;
    height = nextHeight;
    renderer.setPixelRatio(Math.min(devicePixelRatio || 1, width < 760 ? 1.25 : 1.5));
    renderer.setSize(width, height, false);
    camera.right = width;
    camera.bottom = height;
    camera.updateProjectionMatrix();
    buildScene();
    draw(elapsed);
  }

  function tick(now) {
    raf = 0;
    if (disposed || contextLost || paused || !visible || document.hidden) return;
    raf = requestAnimationFrame(tick);
    if (now - lastDraw < 1000 / (width < 760 ? 30 : 45)) return;
    elapsed += lastFrame ? Math.min((now - lastFrame) / 1000, 0.1) : 0;
    lastFrame = lastDraw = now;
    pointer.lerp(pointerTarget, 0.06);
    draw(elapsed);
  }
  function resume() {
    lastFrame = 0;
    if (!raf && !paused && visible && !document.hidden && !disposed && !contextLost) raf = requestAnimationFrame(tick);
  }
  function onVisibility() {
    if (document.hidden) { cancelAnimationFrame(raf); raf = 0; } else resume();
  }
  const resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(hero);
  const observer = new IntersectionObserver(([entry]) => {
    visible = entry.isIntersecting;
    if (visible) resume(); else { cancelAnimationFrame(raf); raf = 0; }
  });
  observer.observe(hero);
  document.addEventListener('visibilitychange', onVisibility);
  function onContextLost(event) {
    event.preventDefault();
    contextLost = true;
    cancelAnimationFrame(raf);
    raf = 0;
    hero.dataset.graphics = 'fallback';
  }
  function onContextRestored() {
    contextLost = false;
    draw(elapsed);
    resume();
  }
  canvas.addEventListener('webglcontextlost', onContextLost);
  canvas.addEventListener('webglcontextrestored', onContextRestored);
  resize();
  resume();
  return {
    setPaused(value) { paused = value; if (paused) { cancelAnimationFrame(raf); raf = 0; } else resume(); },
    setPointer(x, y) { pointerTarget.set(x, y); },
    renderAt(time) { this.setPaused(true); elapsed = time; pointer.set(0, 0); draw(time); },
    dispose() {
      disposed = true; cancelAnimationFrame(raf); observer.disconnect(); resizeObserver.disconnect();
      document.removeEventListener('visibilitychange', onVisibility);
      canvas.removeEventListener('webglcontextlost', onContextLost);
      canvas.removeEventListener('webglcontextrestored', onContextRestored);
      for (const object of scene.children) { object.geometry.dispose(); object.material.dispose(); }
      renderer.dispose();
    },
  };
}
