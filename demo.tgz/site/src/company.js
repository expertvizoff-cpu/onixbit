import { createLightStream } from './light-stream.js';

const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const capture = new URLSearchParams(location.search).get('capture') === '1';
const scene = createLightStream(document.getElementById('light-stream'), document.getElementById('hero'), {reducedMotion:reduced.matches || capture});
const toggle = document.getElementById('company-motion');
let paused = reduced.matches || capture;
function syncMotion() {
  document.body.dataset.motion = paused ? 'paused' : 'playing';
  scene.setPaused(paused);
  toggle.setAttribute('aria-pressed', String(paused));
  toggle.textContent = paused ? 'Включить движение' : 'Остановить движение';
}
toggle.addEventListener('click', () => { paused = !paused; syncMotion(); });
reduced.addEventListener('change', () => { paused = reduced.matches; syncMotion(); });
syncMotion();
if (capture) scene.renderAt(5);

const menuButton = document.getElementById('company-menu-toggle');
const menu = document.getElementById('company-menu');
function closeMenu() { menu.hidden = true; menuButton.setAttribute('aria-expanded','false'); }
menuButton.addEventListener('click', () => { menu.hidden = !menu.hidden; menuButton.setAttribute('aria-expanded',String(!menu.hidden)); });
menu.addEventListener('click', e => { if (e.target.closest('a')) closeMenu(); });
document.addEventListener('keydown', e => { if(e.key==='Escape'&&!menu.hidden){closeMenu();menuButton.focus();} });
const header = document.querySelector('.site-header');
window.addEventListener('scroll', () => header.classList.toggle('is-scrolled',scrollY>24), {passive:true});

// Reuse the site's existing public CRM form; no new endpoint or credentials.
const slot = document.getElementById('company-form-slot');
const fallback = document.getElementById('company-form-fallback');
let formObserver, fallbackTimer;
function loadForm() {
  if(slot.dataset.loaded)return;
  slot.dataset.loaded='true';
  const marker=document.createElement('script');
  marker.dataset.b24Form='inline/24/73tsgu';marker.dataset.skipMoving='true';
  marker.textContent="(function(w,d,u){var s=d.createElement('script');s.async=true;s.src=u+'?'+(Date.now()/180000|0);var h=d.getElementsByTagName('script')[0];h.parentNode.insertBefore(s,h);})(window,document,'https://cdn-ru.bitrix24.ru/b28559462/crm/form/loader_24.js');";
  slot.append(marker);
  fallbackTimer=setTimeout(()=>{if(!slot.querySelector('form,iframe,.b24-form-wrapper'))fallback.hidden=false;},12000);
}
if('IntersectionObserver' in window){formObserver=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){formObserver.disconnect();loadForm();}},{rootMargin:'420px 0px'});formObserver.observe(slot);}else loadForm();
window.addEventListener('pagehide',e=>{if(e.persisted)return;scene.dispose();formObserver?.disconnect();clearTimeout(fallbackTimer);});
