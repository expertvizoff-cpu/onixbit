// Motion observed in the supplied recording: staged charts, floating caps,
// travelling signals and a live dashboard. Timings are reconstructed, not source values.
export function createSceneMotion(root, { paused = false } = {}) {
  const targets = [...root.querySelectorAll('.rs-feature-row,.rs-reliability-card,.rs-heatmap-card,.rs-donut-card,.rs-dashboard-status,.rs-metric-grid>article')];
  const visible = new Set();
  let timer = 0;
  let beat = 0;
  let disposed = false;
  let frozen = paused;
  root.classList.add('rs-motion-ready');
  for (const target of targets) target.classList.add('rs-motion-scene');
  root.querySelectorAll('.rs-timeline-track>i,.rs-mini-bars>i,.rs-data-rules>div').forEach((node, index) => node.style.setProperty('--item-delay', `${(index % 10) * 100}ms`));

  function stop() { clearInterval(timer); timer = 0; }
  function updateDashboard() {
    if (frozen || document.hidden || disposed) return;
    for (const target of visible) {
      if (!target.matches('.rs-heatmap-card')) continue;
      const cells = [...target.querySelectorAll('#rs-heatmap>i')];
      cells.forEach(cell => cell.classList.remove('is-current'));
      cells[((beat % 7) * 7 + 1) % cells.length]?.classList.add('is-current');
      beat++;
    }
  }
  function sync() {
    const suspended = frozen || document.hidden;
    root.dataset.motionSuspended = String(suspended);
    if (suspended || !visible.size) stop();
    else if (!timer) { updateDashboard(); timer = setInterval(updateDashboard, 1400); }
  }
  const observer = new IntersectionObserver(entries => {
    for (const entry of entries) {
      entry.target.classList.toggle('is-in-view', entry.isIntersecting);
      if (entry.isIntersecting) {
        visible.add(entry.target);
        entry.target.classList.add('has-entered');
      } else visible.delete(entry.target);
    }
    sync();
  }, { threshold: 0.12 });
  targets.forEach(target => observer.observe(target));
  document.addEventListener('visibilitychange', sync);
  sync();
  return {
    setPaused(value) {
      frozen = Boolean(value);
      if (frozen) targets.forEach(target => target.classList.add('has-entered'));
      sync();
    },
    dispose() {
      disposed = true;
      stop();
      observer.disconnect();
      document.removeEventListener('visibilitychange', sync);
    },
  };
}
