import { createSceneMotion } from './scene-motion.js';
import { readBrandTheme } from './brand-theme.js';

const SAMPLE_DATA = {
  orders: {
    seed: 3,
    summary: 'Заказ проходит из CRM в 1С, результат возвращается в сделку.',
    route: 'сайт → CRM → 1С',
    statuses: ['Заявка получена', 'Сделка создана', 'Заказ передан'],
    details: ['Сайт → Битрикс24', 'Поля и ответственный', 'Подтверждение из 1С'],
  },
  stock: {
    seed: 7,
    summary: 'Остатки передаются из 1С в каталог, затем проверяется результат обмена.',
    route: '1С → каталог → проверка',
    statuses: ['Остатки получены', 'Каталог обновлён', 'Обмен проверен'],
    details: ['Источник данных — 1С', 'Товары на сайте', 'Статус выполнения'],
  },
  requests: {
    seed: 11,
    summary: 'Обращение с сайта попадает в CRM и назначается ответственному.',
    route: 'форма → CRM → задача',
    statuses: ['Форма отправлена', 'Обращение в CRM', 'Задача назначена'],
    details: ['Пример заявки с сайта', 'Проверка контакта', 'Ответственный в CRM'],
  },
};

export function initSections({ reducedMotion = false } = {}) {
  const root = document.getElementById('relay-sections');
  if (!root) return { dispose() {}, setPaused() {} };

  const sceneMotion = createSceneMotion(root, { paused: reducedMotion });
  const palette = readBrandTheme();
  const disposers = [];
  const revealNodes = [...root.querySelectorAll('[data-reveal]')];
  const foldScene = root.querySelector('.rs-fold-scene');
  const foldPanel = root.querySelector('.rs-fold-panel');
  const foldMark = root.querySelector('.rs-fold-mark');
  const roleCore = root.querySelector('.rs-role-core');
  const foldStage = root.querySelector('.rs-fold-stage');
  // A single visible mark crosses the section boundary. Keeping it outside
  // the collapsing plate and clipped card lets the complete flight stay visible.
  const transferMark = foldMark && roleCore ? foldMark.cloneNode(true) : null;
  if (transferMark) {
    transferMark.className = 'rs-transfer-mark';
    transferMark.hidden = true;
    transferMark.setAttribute('aria-hidden', 'true');
    document.body.append(transferMark);
  }
  let paused = Boolean(reducedMotion);
  let disposed = false;
  let scrollFrame = 0;
  let countFrame = 0;
  let revealObserver;
  let countObserver;
  const ease = value => { const t = Math.max(0, Math.min(1, value)); return t * t * (3 - 2 * t); };

  function updateTransfer(progress, sceneRect) {
    if (!transferMark || !foldStage) return;
    root.classList.add('rs-transfer-ready');
    const source = foldMark.getBoundingClientRect();
    const target = roleCore.getBoundingClientRect();
    const scroll = window.scrollY;
    const sceneTop = sceneRect.top + scroll;
    const departScroll = sceneTop - innerHeight + 0.74 * (innerHeight + sceneRect.height);
    const targetDocY = target.top + scroll + target.height / 2;
    const landScroll = Math.max(departScroll + innerHeight * 0.38, targetDocY - innerHeight * 0.56);
    const stageHeight = foldStage.clientHeight;
    const stickyTop = parseFloat(getComputedStyle(foldStage).top);
    const departY = Math.min(stickyTop, sceneTop + sceneRect.height - departScroll - stageHeight) + stageHeight / 2;
    const t = Math.max(0, Math.min(1, (scroll - departScroll) / (landScroll - departScroll)));
    const blend = ease(t);
    foldPanel.style.setProperty('--fold-presence', scroll >= departScroll ? (1 - ease(t / 0.12)).toFixed(3) : '1');
    let x = source.left + source.width / 2, y = source.top + source.height / 2;
    let size = Math.max(source.width, source.height);
    let phase = 'plate';
    if (scroll >= departScroll) {
      const targetX = target.left + target.width / 2;
      x = innerWidth / 2 + (targetX - innerWidth / 2) * blend;
      y = departY + departScroll + (targetDocY - departY - departScroll) * t - scroll;
      y -= Math.sin(Math.PI * t) * Math.min(150, innerHeight * 0.18);
      size = (innerWidth <= 540 ? 38 : 43) + (target.width - (innerWidth <= 540 ? 38 : 43)) * blend;
      phase = t >= 1 ? 'landed' : 'flight';
    }
    transferMark.hidden = progress < 0.1 || y + size < 0 || y - size > innerHeight;
    transferMark.dataset.phase = phase;
    transferMark.dataset.progress = t.toFixed(4);
    transferMark.style.width = transferMark.style.height = `${size.toFixed(2)}px`;
    transferMark.style.transform = `translate3d(${(x - size / 2).toFixed(2)}px,${(y - size / 2).toFixed(2)}px,0) rotateY(${(Math.sin(Math.PI * t) * 65).toFixed(2)}deg) rotate(${(-Math.sin(Math.PI * t) * 14).toFixed(2)}deg)`;
    const mixColor = (from, to) => `rgb(${from.map((channel, i) => channel + blend * (to[i] - channel)).join(',')})`;
    transferMark.style.backgroundColor = mixColor(palette.sourceBackground, palette.targetBackground);
    transferMark.style.color = mixColor(palette.sourceInk, palette.targetInk);
  }

  function listen(target, event, handler, options) {
    if (!target) return;
    target.addEventListener(event, handler, options);
    disposers.push(() => target.removeEventListener(event, handler, options));
  }

  function updateFold() {
    scrollFrame = 0;
    if (disposed || paused || document.hidden || !foldScene || !foldPanel) return;
    const rect = foldScene.getBoundingClientRect();
    const progress = Math.max(0, Math.min(1, (innerHeight - rect.top) / (innerHeight + rect.height)));
    const open = progress < 0.42 ? ease((progress - 0.12) / 0.30) : progress > 0.60 ? 1 - ease((progress - 0.60) / 0.14) : 1;
    const edge = 1 - open;
    const maxHeight = innerWidth <= 540 ? 300 : innerWidth <= 900 ? 340 : Math.min(520, innerHeight * 0.62);
    const maxWidth = foldStage?.clientWidth || foldScene.clientWidth;
    foldPanel.style.setProperty('--fold-angle', `${(edge * (progress < 0.5 ? 24 : -24)).toFixed(2)}deg`);
    foldPanel.style.setProperty('--fold-scale', '1');
    foldPanel.style.setProperty('--fold-width', `${(64 + (maxWidth - 64) * open).toFixed(1)}px`);
    foldPanel.style.setProperty('--fold-height', `${Math.min(maxHeight,64 + (maxWidth - 64) * open).toFixed(1)}px`);
    foldPanel.style.setProperty('--fold-radius', `${(24 + edge * 24).toFixed(1)}px`);
    foldPanel.style.setProperty('--fold-copy', Math.max(0, (open - 0.68) / 0.32).toFixed(3));
    foldPanel.style.setProperty('--fold-mark-y', `${(open * 75).toFixed(1)}px`);
    foldPanel.dataset.phase = open > 0.99 ? 'open' : progress < 0.5 ? 'opening' : 'closing';
    updateTransfer(progress, rect);
  }

  function scheduleFold() {
    if (!disposed && !paused && !document.hidden && !scrollFrame) scrollFrame = requestAnimationFrame(updateFold);
  }

  function revealAll() {
    for (const node of revealNodes) node.classList.add('is-revealed');
  }

  if ('IntersectionObserver' in window && !reducedMotion) {
    root.classList.add('rs-reveals-ready');
    revealObserver = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        entry.target.classList.add('is-revealed');
        revealObserver.unobserve(entry.target);
      }
    }, { threshold: 0.08, rootMargin: '0px 0px -20px 0px' });
    revealNodes.forEach((node) => revealObserver.observe(node));
  } else revealAll();

  const approval = root.querySelector('.rs-approval');
  const approvalResult = root.querySelector('#rs-approval-result');
  const approvalButtons = [...root.querySelectorAll('[data-approval]')];
  for (const button of approvalButtons) {
    button.setAttribute('aria-pressed', 'false');
    listen(button, 'click', () => {
      const approved = button.dataset.approval === 'approve';
      approval.dataset.result = approved ? 'approve' : 'return';
      for (const control of approvalButtons) control.setAttribute('aria-pressed', String(control === button));
      approvalResult.textContent = approved
        ? 'Пример: согласовано. Следующий шаг — передать заказ в 1С.'
        : 'Пример: возвращено на уточнение. Ответственный получает задачу.';
    });
  }

  const heatmap = root.querySelector('#rs-heatmap');
  const tabPanel = root.querySelector('#rs-dashboard-panel');
  const tabs = [...root.querySelectorAll('[data-dashboard-tab]')];
  const colors = ['#ffd45a0d', '#ffd45a1e', '#ffd45a36', '#ffd45a62', '#ffd45a8c', '#ffd45a'];
  function renderScenario(name) {
    const sample = SAMPLE_DATA[name] || SAMPLE_DATA.orders;
    for (const tab of tabs) {
      const selected = tab.dataset.dashboardTab === name;
      tab.setAttribute('aria-selected', String(selected));
      tab.tabIndex = selected ? 0 : -1;
      if (selected) tabPanel?.setAttribute('aria-labelledby', tab.id);
    }
    if (heatmap) {
      const cells = document.createDocumentFragment();
      for (let index = 0; index < 49; index += 1) {
        const cell = document.createElement('i');
        const day = index % 7;
        const row = Math.floor(index / 7);
        const level = day > 4 ? (index + sample.seed) % 2 : (index * 13 + row * 5 + day * 7 + sample.seed * 3) % 4;
        cell.style.setProperty('--cell-color', colors[level]);
        cells.append(cell);
      }
      heatmap.replaceChildren(cells);
    }
    const summary = root.querySelector('#rs-dashboard-summary');
    const route = root.querySelector('#rs-donut-route');
    if (summary) summary.textContent = sample.summary;
    if (route) route.textContent = sample.route;
    ['input', 'processing', 'output'].forEach((key, index) => {
      const status = root.querySelector(`#rs-status-${key}`);
      const detail = root.querySelector(`#rs-status-${key}-sub`);
      if (status) status.textContent = sample.statuses[index];
      if (detail) detail.textContent = sample.details[index];
    });
  }
  tabs.forEach((tab, index) => {
    listen(tab, 'click', () => renderScenario(tab.dataset.dashboardTab));
    listen(tab, 'keydown', (event) => {
      let next;
      if (event.key === 'ArrowRight') next = (index + 1) % tabs.length;
      if (event.key === 'ArrowLeft') next = (index + tabs.length - 1) % tabs.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = tabs.length - 1;
      if (next === undefined) return;
      event.preventDefault();
      tabs[next].focus();
      renderScenario(tabs[next].dataset.dashboardTab);
    });
  });
  renderScenario('orders');

  const range = root.querySelector('#rs-systems-range');
  const count = root.querySelector('#rs-systems-count');
  const selectedSystems = root.querySelector('#rs-selected-systems');
  const estimateDescription = root.querySelector('#rs-estimate-description');
  const systems = ['Сайт', 'Битрикс24', '1С', 'Телефония', 'Мессенджеры', 'Внутренний сервис'];
  function updateEstimate() {
    if (!range) return;
    const amount = Math.max(2, Math.min(6, Number(range.value) || 3));
    if (count) count.textContent = `${amount} ${amount < 5 ? 'системы' : 'систем'}`;
    range.setAttribute('aria-valuetext', `${amount} ${amount < 5 ? 'системы' : 'систем'}: ${systems.slice(0, amount).join(', ')}`);
    range.style.setProperty('--range-progress', `${(amount - 2) * 25}%`);
    if (selectedSystems) selectedSystems.textContent = systems.slice(0, amount).join(' · ');
    if (estimateDescription) estimateDescription.textContent = amount <= 3
      ? 'Определим данные, направления обмена и правила обработки.'
      : amount <= 5
        ? 'Разделим интеграции на этапы и согласуем ответственность систем.'
        : 'Составим карту связей и выделим первый этап внедрения.';
  }
  listen(range, 'input', updateEstimate);
  updateEstimate();

  const direction = root.querySelector('#rs-project-direction');
  const contactLink = root.querySelector('#rs-contact-link');
  listen(direction, 'change', () => {
    // Selection only adjusts the visible CTA. No input is sent or put in a URL.
    const labels = { integration: 'Обсудить интеграцию', crm: 'Обсудить Битрикс24', website: 'Обсудить сайт' };
    if (contactLink) contactLink.setAttribute('aria-label', `${labels[direction.value] || 'Обсудить задачу'} — перейти к контактам`);
  });

  const demoCount = root.querySelector('[data-demo-count]');
  function finishCount() {
    cancelAnimationFrame(countFrame);
    countFrame = 0;
    if (demoCount) demoCount.textContent = demoCount.dataset.demoCount;
  }
  if (demoCount && 'IntersectionObserver' in window && !reducedMotion) {
    countObserver = new IntersectionObserver((entries) => {
      if (!entries.some((entry) => entry.isIntersecting)) return;
      countObserver.disconnect();
      if (paused || document.hidden) return finishCount();
      const start = performance.now();
      const total = Number(demoCount.dataset.demoCount);
      const tick = (now) => {
        if (disposed || paused || document.hidden) return finishCount();
        const progress = Math.min(1, (now - start) / 620);
        demoCount.textContent = String(Math.min(total, Math.floor(progress * (total + 1))));
        if (progress < 1) countFrame = requestAnimationFrame(tick);
        else finishCount();
      };
      countFrame = requestAnimationFrame(tick);
    }, { threshold: 0.7 });
    countObserver.observe(demoCount);
  }

  listen(window, 'scroll', scheduleFold, { passive: true });
  listen(window, 'resize', scheduleFold, { passive: true });
  listen(document, 'visibilitychange', () => {
    if (document.hidden) {
      cancelAnimationFrame(scrollFrame);
      scrollFrame = 0;
      finishCount();
    } else scheduleFold();
  });

  function setPaused(value) {
    paused = Boolean(value);
    sceneMotion.setPaused(paused);
    root.dataset.paused = String(paused);
    if (paused) {
      root.classList.remove('rs-transfer-ready');
      if (transferMark) transferMark.hidden = true;
      cancelAnimationFrame(scrollFrame);
      scrollFrame = 0;
      finishCount();
      revealAll();
      if (foldPanel) {
        foldPanel.style.setProperty('--fold-angle', '0deg');
        foldPanel.style.setProperty('--fold-scale', '1');
        for (const name of ['width', 'height', 'radius', 'copy', 'mark-y', 'presence']) foldPanel.style.removeProperty(`--fold-${name}`);
        foldPanel.dataset.phase = 'open';
      }
    } else scheduleFold();
  }
  setPaused(paused);

  return {
    setPaused,
    dispose() {
      if (disposed) return;
      disposed = true;
      sceneMotion.dispose();
      transferMark?.remove();
      root.classList.remove('rs-transfer-ready');
      cancelAnimationFrame(scrollFrame);
      finishCount();
      revealObserver?.disconnect();
      countObserver?.disconnect();
      disposers.forEach((dispose) => dispose());
    },
  };
}
