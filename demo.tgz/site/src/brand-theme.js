// Shared with the landing and homepage draft; the CSS tokens are the palette source.
export function readBrandTheme() {
  const style = getComputedStyle(document.documentElement);
  const color = name => style.getPropertyValue(name).trim();
  const rgb = name => {
    const hex = color(name).replace('#', '');
    return [0, 2, 4].map(i => parseInt(hex.slice(i, i + 2), 16));
  };
  return {
    beamPrimary: color('--brand-beam-primary'), beamSecondary: color('--brand-yellow'),
    dust: color('--brand-muted'), sourceBackground: rgb('--brand-surface'),
    targetBackground: rgb('--brand-yellow'), sourceInk: rgb('--brand-yellow'),
    targetInk: rgb('--brand-ink'),
  };
}
